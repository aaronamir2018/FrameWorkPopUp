//
//  NetworkManager.swift
//  MobileVersions
//
//  Created by Hugo Ángeles Chávez on 5/19/18.
//  Copyright © 2018 Hugo Ángeles Chávez. All rights reserved.
//

import Foundation

typealias ErrorHandler = (String) -> Void

enum HTTPMethod : String {
    case post = "POST"
    case get = "GET"
    case put = "PUT"
    case delete = "DELETE"
}

struct ServiceConstants {
    
    static let serverUrl = "https://api.tismartcloud.com/tismart/mobileversion/v1/getlastversion"
    static let platform = "i"
}

class NetworkManager {
    
    private static let timeout: Double = 5
    
    static let shared = NetworkManager()
    
    private func makeRequest<T>(
        withMethod: HTTPMethod,
        url urlStr: String,
        params: [String : Any]? = nil,
        headers: [String : Any]? = nil,
        success: @escaping (T?) -> Void,
        failure: @escaping ErrorHandler) where T : Codable {
        
        guard let url = URL(string: urlStr) else {
            failure("Malformed url")
            return
        }
        
        var request = URLRequest(url: url, cachePolicy: .useProtocolCachePolicy, timeoutInterval: NetworkManager.timeout)
        
        if let requestParams = params {
            request.httpBody = try? JSONSerialization.data(withJSONObject: requestParams, options: .prettyPrinted)
        }
        
        let configuration = URLSessionConfiguration.ephemeral
        configuration.allowsCellularAccess = true
        configuration.httpAdditionalHeaders = headers
        
        let session = URLSession(configuration: configuration)
        let task = session.dataTask(with: request) { (data, urlResponse, error) in
            
            if let anError = error {
                OperationQueue.main.addOperation {
                    failure(anError.localizedDescription)
                }
                return
            }
            
            guard let response = urlResponse as? HTTPURLResponse
                , let responseData = data
                , response.statusCode == 200 else {
                    OperationQueue.main.addOperation {
                        failure("Ocurrio un error en el servicio")
                    }
                    return
            }
            
            do {
                let decoder = JSONDecoder()
                let result = try decoder.decode(T.self, from: responseData)
                OperationQueue.main.addOperation {
                    success(result)
                }
            } catch(let exception) {
                OperationQueue.main.addOperation {
                    failure(exception.localizedDescription)
                }
            }
        }
        task.resume()
    }
    
    func checkVersion(projectName project: String,
                      identifier: String,
                      environment: Environment,
                      state: State,
                      success: @escaping (VersionUpdate?) -> Void,
                      failure: @escaping ErrorHandler) {
        
        let url = "\(ServiceConstants.serverUrl)?project=\(project)&package=\(identifier)&platform=\(ServiceConstants.platform)&environment=\(environment.rawValue)&state=\(state.rawValue)"
        
        print(url)
        
        makeRequest(withMethod: .get, url: url, success: success, failure: failure)
    }
    
}
