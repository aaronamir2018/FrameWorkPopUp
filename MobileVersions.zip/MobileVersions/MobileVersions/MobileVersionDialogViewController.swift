//
//  MobileVersionDialogViewController.swift
//  MobileVersions
//
//  Created by Hugo Ángeles Chávez on 5/19/18.
//  Copyright © 2018 Hugo Ángeles Chávez. All rights reserved.
//

import UIKit

class MobileVersionDialogViewController: UIViewController {
    
    static let tagTitleLabel = 100
    static let tagSubtitleLabel = 101
    static let tagCancelButton = 102
    static let tagUpdateButton = 103
    
    private var versionUpdate: VersionUpdate!
    private var appStore: AppStoreParameters!
    weak var delegate: MobileVersionsDelegate?
    
    var blurredBackgroundView = UIVisualEffectView()

    convenience init(versionUpdate: VersionUpdate,appStore: AppStoreParameters, nibName: String, bundle: Bundle) {
    
        self.init(nibName: nibName, bundle: bundle)
        self.versionUpdate = versionUpdate
        self.appStore = appStore
        
    }

    
    /*
     import MobileVersions

     let appName = Bundle.main.infoDictionary![kCFBundleNameKey as String] as? String

        
     override func viewWillAppear(_ animated: Bool) {
     
     MobileVersions.getLatestVersion(
     viewController: self,
     projectName: appName!,
     environment: .production,
     storeparam: AppStoreParameters(appName: "taxi-vip-cars", appID: "id1130556834"),
     delegate: self)
     }
     
     
     extension ViewController : MobileVersionsDelegate {
     func noUpdateNeeded() {
     print("No necesita actualización")
     }
     
     }
     
     Fonts provided by application
     
     /Frameworks/MobileVersions.framework/SF-Pro-Display-Black.otf
     /Frameworks/MobileVersions.framework/SF-Pro-Display-Bold.otf
     /Frameworks/MobileVersions.framework/SF-Pro-Display-Regular.otf
     
     */
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        blurredBackgroundView.frame = view.bounds
        blurredBackgroundView.effect = UIBlurEffect(style: .dark)
        
        view.addSubview(blurredBackgroundView)
        view.sendSubview(toBack: blurredBackgroundView)

        
        
        if let subtitleLabel = view.viewWithTag(MobileVersionDialogViewController.tagSubtitleLabel) as? UILabel {
            subtitleLabel.text = versionUpdate.required ? MobileVersionsConstants.Strings.message_new_update_mandatory : MobileVersionsConstants.Strings.message_new_update_available
        }
        
        if let cancelButton = view.viewWithTag(MobileVersionDialogViewController.tagCancelButton) as? UIButton {
            cancelButton.isUserInteractionEnabled = true
            let tapCancelGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(buttonCancelTapped(_:)))
            cancelButton.addGestureRecognizer(tapCancelGestureRecognizer)
        }
        
        if let updateButton = view.viewWithTag(MobileVersionDialogViewController.tagUpdateButton) as? UIButton {
            updateButton.isUserInteractionEnabled = true
            let tapUpdateGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(buttonUpdateTapped(_:)))
            updateButton.addGestureRecognizer(tapUpdateGestureRecognizer)
        }
    }
    
    @objc
    func buttonCancelTapped(_ gesture: UITapGestureRecognizer) {
        if versionUpdate.required {
            exit(0)
        } else {
            dismiss(animated: true, completion: nil)
            delegate?.noUpdateNeeded()
            self.delegate = nil
        }
    }
    
    @objc
    func buttonUpdateTapped(_ gesture: UITapGestureRecognizer) {
        // Ir a app store
        print("LLEVAR AL APPSTORE")

        //itms-apps://itunes.apple.com/us/app/taxi-vip-cars/id1130556834
        
        let urlStr = "itms-apps://itunes.apple.com/us/app/" + appStore.appName + "/" + appStore.appID
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(URL(string: urlStr)!, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.openURL(URL(string: urlStr)!)
        }
        dismiss(animated: true, completion: nil)

    }
}
