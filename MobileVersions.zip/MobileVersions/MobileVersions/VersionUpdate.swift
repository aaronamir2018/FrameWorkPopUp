//
//  VersionUpdate.swift
//  MobileVersions
//
//  Created by Hugo Ángeles Chávez on 5/19/18.
//  Copyright © 2018 Hugo Ángeles Chávez. All rights reserved.
//

import Foundation

struct VersionUpdate : Codable {
    let version: String
    let build: String
    let state: String
    let environment: String
    let required: Bool
}
