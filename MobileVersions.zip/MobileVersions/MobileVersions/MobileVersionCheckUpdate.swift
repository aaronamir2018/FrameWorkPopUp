//
//  MobileVersionChecker.swift
//  MobileVersions
//
//  Created by Hugo Ángeles Chávez on 5/19/18.
//  Copyright © 2018 Hugo Ángeles Chávez. All rights reserved.
//

import Foundation

typealias MobileVersionCheckUpdateStateHandler = (MobileVersionCheckUpdateResult) -> Void

class MobileVersionCheckUpdate {
    
    private let networkManager: NetworkManager
    
    init(networkManager: NetworkManager) {
        self.networkManager = networkManager
    }
    
    func execute(
        projectName project: String,
        identifier: String,
        environment: Environment,
        state: State,
        handler: @escaping MobileVersionCheckUpdateStateHandler) {
        
        networkManager.checkVersion(projectName: project, identifier: identifier, environment: environment, state: state, success: { (result: VersionUpdate?) in
            guard let versionUpdate = result else {
                handler(.error(message: "Version update was null"))
                return
            }
            
            guard let myBuildNumberStr = Bundle.main.buildVersionNumber,
                let myBuildNumber = Int64(myBuildNumberStr),
                let serviceBuildNumber = Int64(versionUpdate.build) else {
                    handler(.error(message: "Unexpected build number format"))
                    return
            }
            
            if myBuildNumber >= serviceBuildNumber {
                handler(.latestVersion)
                return
            }
            
            if versionUpdate.required {
                handler(.newVersionAvailableRequired(versionUpdate: versionUpdate))
            } else {
                handler(.newVersionAvailable(versionUpdate: versionUpdate))
            }
        }, failure: { error in
            handler(.error(message: error))
        })
    }
}
